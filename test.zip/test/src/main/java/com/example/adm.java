package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
public class adm extends HttpServlet {


    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        out.println("<body>");
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println("Connecting to a selected database...");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cloth", "root", "root");
            System.out.println("Connected database successfully...");
            Statement smt = conn.createStatement();
           out.println("<h1>Welcome to Admin page</h1>");
           out.println("<h3>SHIRTS</h3>");
           out.println("<h4>Product id:1</h4>");
           ResultSet rs=smt.executeQuery("select * from ol where pid='1'");
           double p=0.0;
           while(rs.next()){
              p=Double.parseDouble(rs.getString(3));

           }
           out.println("<h4>Current price:"+p+"</h4>");
           out.println("<hr></hr>");

           out.println("<h3>T-SHIRTS</h3>");
           out.println("<h4>Product id:2</h4>");
           ResultSet rs1=smt.executeQuery("select * from ol where pid='2'");
           double k=0.0;
           while(rs1.next()){
            k=Double.parseDouble(rs1.getString(3));

         }
           out.println("<h4>Current price:"+k+"</h4>");
           out.println("<hr></hr>");

           out.println("<h3>COATS</h3>");
           out.println("<h4>Product id:3</h4>");
           ResultSet rs2=smt.executeQuery("select * from ol where pid='3'");
           double p2=0.0;
           while(rs2.next()){
            p2=Double.parseDouble(rs2.getString(3));

         }
           out.println("<h4>Current price:"+p2+"</h4>");
           out.println("<hr></hr>");

           out.println("<h3>PANTS</h3>");
           out.println("<h4>Product id:4</h4>");
           ResultSet rs3=smt.executeQuery("select * from ol where pid='4'");
           double p3=0.0;
           while(rs3.next()){
            p3=Double.parseDouble(rs3.getString(3));

         }
           out.println("<h4>Current price:"+p3+"</h4>");
           out.println("<hr></hr>");

           out.println("<h1>Id of product to be deleted</h1>");
           out.println("<form action='sdd' method='post'>");
           out.println("<input type='text' name='name' required>");
           out.println("<input type='submit' value='Delete'>");
           out.println("</form>");

           out.println("<h1>Product to be updated</h1>");
           out.println("<form action='sdf' method='post'>");
           out.println("<h3>Product ID</h3>");
           out.println("<input type='text' name='id' required>");
           out.println("<h3>Updated price<h3>");
           out.println("<input type='text' name='pr' required>");
           out.println("<input type='submit' value='Update'>");
           out.println("</form>");
           out.println("</body>");
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            out.close();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}