package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class servlet extends HttpServlet {


    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out=response.getWriter();
        out.println("<body>");
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println("Connecting to a selected database...");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/info", "root", "root");
            System.out.println("Connected database successfully...");
            Statement smt = conn.createStatement();
            String name=request.getParameter("name");
            String password=request.getParameter("password");
            ResultSet result=smt.executeQuery("select * from ol");
            smt.executeUpdate("insert into ol(username,password) values('" + name + "','" + password + "')");
            System.out.println("Inserted successfully!");
            out.println("<h1>Successfully registered</h1>");
            out.println("<form action='index.html' method='post'><input type='submit' value='Redirect to sign up page'></form>");
            out.println("</body>");
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            out.close();
        }
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}