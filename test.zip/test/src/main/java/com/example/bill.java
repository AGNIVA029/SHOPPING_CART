package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
public class bill extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /* Usage of some methods in HttpServletResponse and ServletResponse interfaces */
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        out.println("<body>");
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            ServletContext context=getServletContext();  
            String n=(String)context.getAttribute("u");
            System.out.println("Connecting to a selected database...");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cloth", "root", "root");
            System.out.println("Connected database successfully...");
            Statement smt = conn.createStatement();
           out.println("<h1>Welcome to Bill page</h1>");
           out.println("<h1>Customer name:"+n+"</h1>");
           out.println("<hr></hr>");
           out.println("<h3>Products bought");
           ResultSet rs=smt.executeQuery("select * from ol");
           int c=0;
           String prod[]=new String[4];
           int price[]=new int[4];
           while(rs.next()){
            prod[c]=rs.getString(2);
            price[c]=Integer.parseInt(rs.getString(3));
            c++;
           }

           double b=0.0;

           if(!(request.getParameter("name").equals(""))){
            int a1=Integer.parseInt(request.getParameter("name"));
            b+=(price[0]*a1);
            out.println("<h4>"+prod[0]+"</h4>");
            out.println("<h4>Quantity:"+a1+"</h4>");
            out.println("<h4>Price:"+price[0]+"</h4>");
            out.println("<hr></hr>");
           }

           if(!(request.getParameter("name2").equals(""))){
            int a2=Integer.parseInt(request.getParameter("name2"));
            b+=(price[1]*a2);
            out.println("<h4>"+prod[1]+"</h4>");
            out.println("<h4>Quantity:"+a2+"</h4>");
            out.println("<h4>Price:"+price[1]+"</h4>");
            out.println("<hr></hr>");
           }

           if(!(request.getParameter("name3").equals(""))){
            int a3=Integer.parseInt(request.getParameter("name3"));
            b+=(price[2]*a3);
            out.println("<h4>"+prod[2]+"</h4>");
            out.println("<h4>Quantity:"+a3+"</h4>");
            out.println("<h4>Price:"+price[2]+"</h4>");
            out.println("<hr></hr>");
           }

           if(!(request.getParameter("name4").equals(""))){
            int a4=Integer.parseInt(request.getParameter("name4"));
            b+=(price[3]*a4);
            out.println("<h4>"+prod[3]+"</h4>");
            out.println("<h4>Quantity:"+a4+"</h4>");
            out.println("<h4>Price:"+price[3]+"</h4>");
            out.println("<hr></hr>");
           }

           out.println("<h2>Total bill:"+"<h2>"+b+"</h2>");
           Connection conn2 = DriverManager.getConnection("jdbc:mysql://localhost/bill", "root", "root");
            System.out.println("Connected database successfully...");
            Statement smt2 = conn2.createStatement();
            smt2.executeUpdate("insert into ol(Name,Amount) values('" + n + "','" + b + "')");

        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            out.close();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}