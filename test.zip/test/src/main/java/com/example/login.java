package com.example;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class login extends HttpServlet {


    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        out.println("<body>");
        try{
        out.println("<h1>LOGIN PAGE</h1>");
        out.println("<div id='container'>");
        out.println("<div class='signup'>");
        out.println("<form action='a' method='post'>");
        out.println("<input type='text' name='name' placeholder='Enter username' required><br><br>");
        out.println("<input type='password' name='password' placeholder='Enter password' required><br><br>");
        out.println("<input type='submit' value='login'>");
        out.println("</form>");
        out.println("<br>"); 
        out.println("</div>");
        out.println("</div>");
        out.println("</body>");
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            out.close();
        }
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}
