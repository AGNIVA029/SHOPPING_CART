package com.example;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
public class cart extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /* Usage of some methods in HttpServletResponse and ServletResponse interfaces */
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out=response.getWriter();
        out.println("<body>");
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");

            System.out.println("Connecting to a selected database...");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/cloth", "root", "root");
            System.out.println("Connected database successfully...");
            Statement smt = conn.createStatement();
           out.println("<h1>Welcome to Cart page</h1>");
           ResultSet rs=smt.executeQuery("select * from ol");
           String id[]=new String[4];int c=0;
           String prod[]=new String[4];
           String price[]=new String[4];
           while(rs.next()){
            id[c]=rs.getString(1);
            prod[c]=rs.getString(2);
            price[c]=rs.getString(3);
            c++;
           }
           out.println("<form action='bi' method='post'>");
           out.println("<h4>Product:"+prod[0]+"</h4>");
           out.println("<h4>Product ID:"+id[0]+"</h4>");
           out.println("<h4>Product price:"+price[0]+"</h4>");
           out.println("<h4>Quantity</h4>");
           out.println("<input type='text' name='name'>");
           out.println("<hr></hr>");

           out.println("<h4>Product:"+prod[1]+"</h4>");
           out.println("<h4>Product ID:"+id[1]+"</h4>");
           out.println("<h4>Product price:"+price[1]+"</h4>");
           out.println("<h4>Quantity</h4>");
           out.println("<input type='text' name='name2'>");
           out.println("<hr></hr>");

           out.println("<h4>Product:"+prod[2]+"</h4>");
           out.println("<h4>Product ID:"+id[2]+"</h4>");
           out.println("<h4>Product price:"+price[2]+"</h4>");
           out.println("<h4>Quantity</h4>");
           out.println("<input type='text' name='name3'>");
           out.println("<hr></hr>");

           out.println("<h4>Product:"+prod[3]+"</h4>");
           out.println("<h4>Product ID:"+id[3]+"</h4>");
           out.println("<h4>Product price:"+price[3]+"</h4>");
           out.println("<h4>Quantity</h4>");
           out.println("<input type='text' name='name4'>");
           out.println("<hr></hr>");
           out.println("<input type='submit' value='Buy selected items'>");
           out.println("</form>");
           out.println("</body>");
        }
        catch(Exception e){
            System.out.println(e);
        }
        finally{
            out.close();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}